const scroll = new LocomotiveScroll({
    el: document.querySelector("#scroll-container"),
    smooth: true,
});
